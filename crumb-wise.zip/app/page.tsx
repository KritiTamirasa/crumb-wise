"use client"

import { useState } from "react"
import Dashboard from "@/components/dashboard"
import PantryTracker from "@/components/pantry-tracker"
import RecipeSuggestions from "@/components/recipe-suggestions"
import FoodBankConnection from "@/components/food-bank-connection"
import AppHeader from "@/components/app-header"
import MobileNavigation from "@/components/mobile-navigation"

export default function Home() {
  const [activeTab, setActiveTab] = useState("dashboard")

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <Dashboard />
      case "pantry":
        return <PantryTracker />
      case "recipes":
        return <RecipeSuggestions />
      case "foodbank":
        return <FoodBankConnection />
      default:
        return <Dashboard />
    }
  }

  return (
    <main className="flex min-h-screen flex-col items-center bg-[#f8f5f2]">
      <div className="w-full max-w-md mx-auto h-screen flex flex-col">
        <div className="flex-1 overflow-y-auto pb-16">
          <AppHeader />
          {renderContent()}
        </div>
        <MobileNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </main>
  )
}
