import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, ChefHat, ThumbsUp } from "lucide-react"

export default function RecipeSuggestions() {
  const recipes = [
    {
      id: 1,
      title: "Banana Bread",
      description: "Perfect for using overripe bananas and leftover flour",
      time: "45 mins",
      difficulty: "Easy",
      ingredients: ["Overripe Bananas", "Flour", "Eggs"],
      image: "/placeholder.svg?height=100&width=150",
      usesSoon: ["Eggs", "Flour"],
    },
    {
      id: 2,
      title: "Almond Milk Pancakes",
      description: "Delicious breakfast option using almond milk before it expires",
      time: "20 mins",
      difficulty: "Easy",
      ingredients: ["Almond Milk", "Flour", "Eggs"],
      image: "/placeholder.svg?height=100&width=150",
      usesSoon: ["Almond Milk", "Eggs"],
    },
    {
      id: 3,
      title: "Egg Custard Tarts",
      description: "Classic pastry to use up eggs and milk",
      time: "1 hour",
      difficulty: "Medium",
      ingredients: ["Eggs", "Milk", "Flour", "Butter"],
      image: "/placeholder.svg?height=100&width=150",
      usesSoon: ["Eggs", "Almond Milk"],
    },
  ]

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-semibold text-green-800">Recipe Suggestions</h2>
      <p className="text-sm text-gray-600">Based on your expiring ingredients</p>

      <Tabs defaultValue="expiring" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="expiring">Expiring Soon</TabsTrigger>
          <TabsTrigger value="all">All Recipes</TabsTrigger>
        </TabsList>
        <TabsContent value="expiring" className="mt-4 space-y-4">
          {recipes.map((recipe) => (
            <Card key={recipe.id} className="overflow-hidden">
              <div className="flex">
                <div className="w-1/3">
                  <img
                    src={recipe.image || "/placeholder.svg"}
                    alt={recipe.title}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="w-2/3">
                  <CardContent className="p-3">
                    <div className="space-y-2">
                      <div className="flex justify-between items-start">
                        <h3 className="font-medium">{recipe.title}</h3>
                        <ThumbsUp className="h-4 w-4 text-green-600" />
                      </div>
                      <p className="text-xs text-gray-500">{recipe.description}</p>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Clock className="h-3 w-3" />
                        <span>{recipe.time}</span>
                        <ChefHat className="h-3 w-3 ml-2" />
                        <span>{recipe.difficulty}</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {recipe.usesSoon.map((ingredient) => (
                          <Badge
                            key={ingredient}
                            variant="outline"
                            className="text-xs bg-green-50 text-green-700 border-green-200"
                          >
                            Uses {ingredient}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="p-3 pt-0">
                    <Button variant="outline" size="sm" className="w-full text-xs">
                      View Recipe
                    </Button>
                  </CardFooter>
                </div>
              </div>
            </Card>
          ))}
        </TabsContent>
        <TabsContent value="all" className="mt-4">
          <div className="text-center py-8 text-gray-500">
            <p>Browse our full recipe collection</p>
            <Button variant="outline" className="mt-2">
              Explore All Recipes
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
