import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertTriangle, TrendingUp, Leaf } from "lucide-react"

export default function Dashboard() {
  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-semibold text-green-800">Welcome back, Green Bakery!</h2>

      <Alert className="bg-amber-50 border-amber-200">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <AlertTitle className="text-amber-800">Expiring Soon</AlertTitle>
        <AlertDescription className="text-amber-700">5 ingredients will expire in the next 48 hours</AlertDescription>
      </Alert>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Pantry Status</CardTitle>
          <CardDescription>Track your inventory health</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Flour</span>
              <span className="text-amber-600">75% (3 days left)</span>
            </div>
            <Progress value={75} className="h-2 bg-gray-200" />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Eggs</span>
              <span className="text-red-600">90% (1 day left)</span>
            </div>
            <Progress value={90} className="h-2 bg-gray-200" />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Milk</span>
              <span className="text-red-600">95% (Today)</span>
            </div>
            <Progress value={95} className="h-2 bg-gray-200" />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Waste Reduction</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Leaf className="h-8 w-8 text-green-600 mr-2" />
              <div>
                <p className="text-2xl font-bold text-green-700">32%</p>
                <p className="text-xs text-green-600">This month</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Efficiency</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 text-blue-600 mr-2" />
              <div>
                <p className="text-2xl font-bold text-blue-700">18%</p>
                <p className="text-xs text-blue-600">Increase</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
