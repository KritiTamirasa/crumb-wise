import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, MapPin, Calendar, ArrowRight } from "lucide-react"

export default function FoodBankConnection() {
  const foodBanks = [
    {
      id: 1,
      name: "Community Food Share",
      distance: "1.2 miles",
      needs: ["Flour", "Sugar", "Eggs"],
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      id: 2,
      name: "Local Hunger Relief",
      distance: "2.8 miles",
      needs: ["Bread", "Pastries", "Dairy"],
      image: "/placeholder.svg?height=60&width=60",
    },
    {
      id: 3,
      name: "City Food Bank",
      distance: "3.5 miles",
      needs: ["Baked Goods", "Flour", "Sugar"],
      image: "/placeholder.svg?height=60&width=60",
    },
  ]

  return (
    <div className="p-4 space-y-4">
      <div className="text-center mb-6">
        <Heart className="h-12 w-12 text-red-500 mx-auto mb-2" />
        <h2 className="text-xl font-semibold text-green-800">Food Bank Connection</h2>
        <p className="text-sm text-gray-600 mt-1">Donate your excess ingredients to local food banks</p>
      </div>

      <Card className="bg-green-50 border-green-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg text-green-800">Your Impact</CardTitle>
          <CardDescription>This month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-green-700">24 lbs</p>
              <p className="text-xs text-green-600">Food Donated</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-green-700">18</p>
              <p className="text-xs text-green-600">Meals Provided</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <h3 className="font-medium text-gray-700 mt-6">Nearby Food Banks</h3>

      <div className="space-y-4">
        {foodBanks.map((foodBank) => (
          <Card key={foodBank.id}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-100">
                  <img
                    src={foodBank.image || "/placeholder.svg"}
                    alt={foodBank.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium">{foodBank.name}</h4>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span>{foodBank.distance}</span>
                  </div>
                </div>
              </div>

              <div className="mt-3">
                <p className="text-xs text-gray-500 mb-1">Currently needs:</p>
                <div className="flex flex-wrap gap-1">
                  {foodBank.needs.map((need) => (
                    <Badge key={need} variant="outline" className="text-xs">
                      {need}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
            <CardFooter className="px-4 py-2 border-t flex justify-between items-center">
              <div className="flex items-center text-xs text-gray-500">
                <Calendar className="h-3 w-3 mr-1" />
                <span>Next pickup: Tomorrow</span>
              </div>
              <Button variant="ghost" size="sm" className="h-8 gap-1">
                Connect
                <ArrowRight className="h-3 w-3" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
