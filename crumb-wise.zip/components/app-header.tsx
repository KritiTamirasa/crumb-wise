import { Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function AppHeader() {
  return (
    <header className="sticky top-0 z-10 bg-[#f8f5f2] border-b border-green-100 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-green-600 flex items-center justify-center">
            <span className="text-white font-bold text-sm">CW</span>
          </div>
          <h1 className="text-xl font-bold text-green-800">Crumb Wise</h1>
        </div>
        <div className="relative">
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5 text-green-700" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-red-500">
              3
            </Badge>
          </Button>
        </div>
      </div>
    </header>
  )
}
