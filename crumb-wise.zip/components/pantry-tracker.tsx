"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, Camera, AlertCircle } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { CalendarIcon } from "lucide-react"

export default function PantryTracker() {
  const [date, setDate] = useState<Date>()
  const [searchQuery, setSearchQuery] = useState("")

  const pantryItems = [
    { id: 1, name: "Organic Flour", quantity: "5 kg", expiry: "Jun 7, 2025", status: "critical" },
    { id: 2, name: "Free-range Eggs", quantity: "24 units", expiry: "Jun 8, 2025", status: "warning" },
    { id: 3, name: "Almond Milk", quantity: "2 L", expiry: "Jun 6, 2025", status: "critical" },
    { id: 4, name: "Butter", quantity: "500 g", expiry: "Jun 12, 2025", status: "good" },
    { id: 5, name: "Cane Sugar", quantity: "3 kg", expiry: "Aug 15, 2025", status: "good" },
    { id: 6, name: "Vanilla Extract", quantity: "200 ml", expiry: "Dec 20, 2025", status: "good" },
  ]

  const filteredItems = pantryItems.filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search ingredients..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="icon" className="bg-green-600 hover:bg-green-700">
              <Camera className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Scan Item</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="relative w-full h-48 bg-gray-900 rounded-md overflow-hidden flex items-center justify-center">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-64 h-64 border-2 border-white/30 rounded-md"></div>
                  <div className="absolute top-1/2 left-1/2 w-48 h-1 bg-green-500/50 transform -translate-x-1/2 -translate-y-1/2"></div>
                </div>
                <div className="text-white/70 text-sm">Camera simulation</div>
              </div>

              <div className="bg-green-50 p-3 rounded-md border border-green-100">
                <h3 className="font-medium text-green-800 flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Item Recognized
                </h3>
                <p className="text-sm text-green-700 mt-1">Organic Flour (5kg)</p>
                <p className="text-xs text-green-600 mt-1">Expiry: 7 days from today</p>
              </div>

              <div className="grid gap-2">
                <Label>Adjust Quantity (if needed)</Label>
                <Input defaultValue="5 kg" />
              </div>

              <div className="grid gap-2">
                <Label>Adjust Expiry Date (if needed)</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : <span>Jun 13, 2025</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>

              <Button className="w-full bg-green-600 hover:bg-green-700">Add to Pantry</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {filteredItems.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <CardContent className="p-0">
              <div className="flex items-center p-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium">{item.name}</h3>
                    {item.status === "critical" && (
                      <Badge variant="destructive" className="text-xs">
                        Expires Today
                      </Badge>
                    )}
                    {item.status === "warning" && (
                      <Badge variant="outline" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                        Soon
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    <span>{item.quantity}</span>
                    <span className="mx-2">•</span>
                    <span
                      className={cn(
                        item.status === "critical" && "text-red-600 font-medium",
                        item.status === "warning" && "text-amber-600",
                      )}
                    >
                      Expires: {item.expiry}
                    </span>
                  </div>
                </div>
                {item.status === "critical" && <AlertCircle className="h-5 w-5 text-red-500" />}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
